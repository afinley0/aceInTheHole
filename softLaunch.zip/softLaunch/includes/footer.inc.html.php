<footer>

    <!-- Footer navigation -->
    <!-- Footer nav goes to these places : Contact | Register | FAQ | About | Packet Info | Events -->
    <!-- Links for FAQ & Packet info will go directly to that part of the page -->
    <div class="center">
        <a href="https://www.facebook.com/Cas222Aceinthehole-110661963841617/"><i class="fab fa-facebook-square"></i></a>
        <a href="https://twitter.com/pcccas222?lang=en"><i class="fab fa-twitter"></i></a>
    </div>
    <div class="footercol footer-nav">
        <ul class="fnav">
            <li class="fnav"><a class="fnav" href="<?php echo ACE_URL; ?>about/about.html.php">About</a></li>
            <li class="fnav"><a class="fnav" href="<?php echo ACE_URL; ?>register">Register</a></li>
            <li class="fnav"><a class="fnav" href="<?php echo ACE_URL; ?>contact">Contact Us</a></li>
        </ul>
        <ul class="fnav">
            <li class="fnav"><a class="fnav" href="<?php echo ACE_URL; ?>events">Events</a></li>
            <li class="fnav"><a class="fnav" href="<?php echo ACE_URL; ?>events/events.html.php#Packet">Packet Info</a></li>
            <li class="fnav"><a class="fnav" href="<?php echo ACE_URL; ?>faq">FAQ</a></li>
        </ul>
    </div>

    <!-- Social Media Icons & Copyright Info -->
    <i class="far fa-copyright fa-lg"></i> 2020

</footer>

