<footer>

    <!-- Footer navigation -->
    <!-- Footer nav goes to these places : Contact | Register | FAQ | About | Packet Info | Events -->
    <!-- Links for FAQ & Packet info will go directly to that part of the page -->

    <div class="footercol footer-nav">

        <ul class="fnav">
            <li class="fnav"><a class="fnav" href="about.html">About</a></li>
            <li class="fnav"><a class="fnav" href="register.html">Register</a></li>
            <li class="fnav"><a class="fnav" href="contact.html">Contact Us</a></li>
        </ul>
        <ul class="fnav">
            <li class="fnav"><a class="fnav" href="events.html">Events</a></li>
            <li class="fnav"><a class="fnav" href="#packet">Packet Info</a></li>
            <li class="fnav"><a class="fnav" href="#faq">FAQ</a></li>
        </ul>
    </div>

    <!-- Social Media Icons & Copyright Info -->
    <i class="far fa-copyright fa-lg"></i> 2020

</footer>

