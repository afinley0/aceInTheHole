<!-- Sticky Navigation -->
            <nav class="navbar">
                <a href="index.html">Home</a>
                <a href="about.html">About</a>
                <a href="events.html">Events</a>
                <a href="register.html">Register</a>
                <a href="contact.html">Contact</a>

            </nav> <!-- End Navigation -->

            <!-- Hamburger Menu -->
            <div class="topnav">
                <a href="#home" class="active">Ace in the Hole MultiSport Events</a>
                <div id="myLinks">
                    <a href="index.html">Home</a>
                    <a href="about.html">About</a>
                    <a href="events.html">Events</a>
                    <a href="register.html">Register</a>
                    <a href="contact.html">Contact</a>
                </div>
                <!-- "Hamburger menu" / "Bar icon" to toggle the navigation links -->
                <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                    <i class="fa fa-bars"></i>
                </a>
            </div> <!-- End Hamburger Menu -->

        </header>
