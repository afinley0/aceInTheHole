<!-- Sidebar left -->

<div class="sidebar">
    <h3>Sidebar</h3>
    <p>Social Media Feed</p>
    <p>Weather Feed</p>
</div>

<div class="content">
    <!-- Place holder image -->
    <img class="homeImg" src="images/placeHolderImg.png" alt="Just a place holder for now">

    <!-- Text -->
    <h2>Heading 1</h2>
    <p>Welcome statement. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
    <br>
    <h3>Heading 2</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
    <br>
</div>
