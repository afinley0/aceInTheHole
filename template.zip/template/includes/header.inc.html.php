<?php define('BASE_URL', '/cas222/template/'); ?>

<header>
    <!-- Automatic Slideshow -->
    <div class="automaticSlideshow">
        <img class="mySlides" src="images/logo1.png" style="width:100%">
        <img class="mySlides" src="images/ace3.jpg" style="width:100%">
        <img class="mySlides" src="images/ace6.jpg" style="width:100%">
        <img class="mySlides" src="images/ace15.jpg" style="width:100%">
    </div>


